﻿class Overview
{
    public virtual void Display(object customization)
    {
        Console.WriteLine("Overview: General Customization");
    }
}
